export class Comentario {
    id:number | undefined;
    comentario:string | undefined;    
    idpost:string | undefined;
    autor:string | undefined;
}