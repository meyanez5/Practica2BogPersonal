export class CreateComenarioDto {
    comentario:string | undefined;    
    idpost:string | undefined;
    autor:string | undefined;
}